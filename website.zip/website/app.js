/* ==========================================================
   1. Theme Management (Aligned with Tauri theme.js)
   ========================================================== */
let isLightMode = false;

function initTheme() {
    const savedTheme = localStorage.getItem('vocalmap_theme');
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        const isLight = window.matchMedia('(prefers-color-scheme: light)').matches;
        setTheme(isLight ? 'light' : 'dark');
    }
}

function setTheme(theme) {
    isLightMode = (theme === 'light');
    if (isLightMode) {
        document.documentElement.setAttribute('data-theme', 'light');
    } else {
        document.documentElement.removeAttribute('data-theme');
    }
}

function toggleSimTheme() {
    const newTheme = isLightMode ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('vocalmap_theme', newTheme);
}

// Global mouse tracker for glassmorphism panels (Tauri App Mouse edge shine)
function initMouseGlowTracker() {
    document.addEventListener('mousemove', (e) => {
        const panels = document.querySelectorAll('.glass-panel');
        panels.forEach(panel => {
            const rect = panel.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            panel.style.setProperty('--mouse-x', `${x}px`);
            panel.style.setProperty('--mouse-y', `${y}px`);
        });
    });
}

/* ==========================================================
   2. Version Info & Releases Parser (latest.json Local)
   ========================================================== */
function loadVersionInfo() {
    const defaultVersion = "3.1.2";
    const defaultMirrorUrl = "https://ghproxy.net/https://github.com/DX-Protst/VocalMap-Release/releases/download/v3.1.2/VocalMap_3.1.2_x64-setup.exe";
    const defaultGithubUrl = "https://github.com/DX-Protst/VocalMap-Release/releases/download/v3.1.2/VocalMap_3.1.2_x64-setup.exe";

    fetch('latest.json')
        .then(response => {
            if (!response.ok) throw new Error("Could not load local latest.json");
            return response.json();
        })
        .then(data => {
            if (data && data.version) {
                const version = data.version;
                const winData = data.platforms && data.platforms["windows-x86_64"];
                
                let mirrorUrl = winData ? winData.url : defaultMirrorUrl;
                if (mirrorUrl && !mirrorUrl.startsWith('https://ghproxy.net/')) {
                    mirrorUrl = 'https://ghproxy.net/' + mirrorUrl;
                }
                const githubUrl = winData ? winData.url.replace('https://ghproxy.net/', '') : defaultGithubUrl;

                updateVersionDOM(version, mirrorUrl, githubUrl);
            }
        })
        .catch(err => {
            console.log("Using static version fallback.", err);
            updateVersionDOM(defaultVersion, defaultMirrorUrl, defaultGithubUrl);
        });
}

function updateVersionDOM(version, mirrorUrl, githubUrl) {
    const tags = ['latest-version-tag', 'latest-version-tag-sub', 'sim-version-badge'];
    tags.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = "v" + version;
    });

    const mirrorBtn = document.getElementById('direct-mirror-btn');
    if (mirrorBtn) mirrorBtn.href = mirrorUrl;

    const githubBtn = document.getElementById('direct-github-btn');
    if (githubBtn) githubBtn.href = githubUrl;
}

/* ==========================================================
   3. Tab Switches (Workstation Mockup)
   ========================================================== */
let activeSimTab = 'free';

function switchSimTab(tabId) {
    activeSimTab = tabId;
    const tabBtnFree = document.getElementById('btnTabFree');
    const tabBtnPro = document.getElementById('btnTabPro');
    const freeWS = document.getElementById('simFreeWorkspace');
    const proWS = document.getElementById('simProWorkspace');

    if (tabId === 'free') {
        tabBtnFree.classList.add('active');
        tabBtnPro.classList.remove('active');
        freeWS.style.display = 'flex';
        proWS.style.display = 'none';
        stopTrainingLoop();
    } else {
        tabBtnFree.classList.remove('active');
        tabBtnPro.classList.add('active');
        freeWS.style.display = 'none';
        proWS.style.display = 'block';
        switchSimProTab(activeProSubTab);
    }
}

let activeProSubTab = 'sing';

function switchSimProTab(subTabId) {
    activeProSubTab = subTabId;
    const btnSing = document.getElementById('btnSubTabSing');
    const btnTrain = document.getElementById('btnSubTabTrain');
    const btnSep = document.getElementById('btnSubTabSep');

    const stateSing = document.getElementById('simStateSing');
    const stateTrain = document.getElementById('simStateTrain');
    const stateSep = document.getElementById('simStateSep');

    btnSing.classList.remove('active-mini');
    btnTrain.classList.remove('active-mini');
    btnSep.classList.remove('active-mini');

    stateSing.style.display = 'none';
    stateTrain.style.display = 'none';
    stateSep.style.display = 'none';

    if (subTabId === 'sing') {
        btnSing.classList.add('active-mini');
        stateSing.style.display = 'block';
        stopTrainingLoop();
    } else if (subTabId === 'train') {
        btnTrain.classList.add('active-mini');
        stateTrain.style.display = 'block';
        initTrainingView();
    } else {
        btnSep.classList.add('active-mini');
        stateSep.style.display = 'block';
        stopTrainingLoop();
    }
}

function toggleFaq(triggerElement) {
    const faqItem = triggerElement.parentElement;
    const isActive = faqItem.classList.contains('active');
    
    const allItems = document.querySelectorAll('.faq-item');
    allItems.forEach(item => {
        item.classList.remove('active');
    });

    if (!isActive) {
        faqItem.classList.add('active');
    }
}

/* ==========================================================
   4. Simulation: Realtime Monitor (Free Workspace)
   ========================================================= */
let monitorCanvas = null;
let monitorCtx = null;
let monitorAnimFrame = null;
let monitorPoints = [];
let monitorTime = 0;

let isRecordingMonitor = false;
let recordSeconds = 0;
let recordTimerInterval = null;
let recordedTrajectory = [];

function initRealtimeMonitor() {
    monitorCanvas = document.getElementById('simPitchCanvas');
    if (!monitorCanvas) return;
    monitorCtx = monitorCanvas.getContext('2d');
    
    monitorCanvas.width = monitorCanvas.parentElement.clientWidth;
    monitorCanvas.height = 360;

    window.addEventListener('resize', () => {
        if (monitorCanvas) {
            monitorCanvas.width = monitorCanvas.parentElement.clientWidth;
        }
    });

    animateMonitor();
    setInterval(fluctuateMonitorGauges, 120);
}

function animateMonitor() {
    monitorCtx.clearRect(0, 0, monitorCanvas.width, monitorCanvas.height);
    
    monitorCtx.strokeStyle = isLightMode ? 'rgba(0,0,0,0.04)' : 'rgba(255,255,255,0.03)';
    monitorCtx.lineWidth = 1;
    const step = 30;
    for (let y = step; y < monitorCanvas.height; y += step) {
        monitorCtx.beginPath();
        monitorCtx.moveTo(0, y);
        monitorCtx.lineTo(monitorCanvas.width, y);
        monitorCtx.stroke();
    }

    const targetY = 160;
    monitorCtx.fillStyle = 'rgba(0, 229, 255, 0.08)';
    monitorCtx.strokeStyle = 'rgba(0, 229, 255, 0.2)';
    monitorCtx.fillRect(0, targetY - 15, monitorCanvas.width, 30);
    monitorCtx.beginPath();
    monitorCtx.moveTo(0, targetY - 15);
    monitorCtx.lineTo(monitorCanvas.width, targetY - 15);
    monitorCtx.moveTo(0, targetY + 15);
    monitorCtx.lineTo(monitorCanvas.width, targetY + 15);
    monitorCtx.stroke();
    
    monitorCtx.fillStyle = 'rgba(0, 229, 255, 0.3)';
    monitorCtx.font = '10px sans-serif';
    monitorCtx.fillText("C#4 (277.18Hz) 目标音区", 15, targetY - 20);

    if (!activePlaybackProject) {
        let currentY;
        if (simMicStream && simMicPitchHz > 0) {
            const userMidi = hzToMidi(simMicPitchHz);
            currentY = 160 - (userMidi - 61) * 15; // C#4 (61) is mapped to Y=160
        } else if (simMicStream) {
            currentY = -1; // Silent / rest
        } else {
            monitorTime += 0.085;
            const currentYSim = targetY + Math.sin(monitorTime) * 12 + Math.cos(monitorTime * 2.1) * 3 + (Math.random() - 0.5) * 2;
            currentY = currentYSim;
        }
        
        monitorPoints.push(currentY);
        if (monitorPoints.length > 250) {
            monitorPoints.shift();
        }
    }

    monitorCtx.strokeStyle = '#00FFF5';
    monitorCtx.shadowColor = '#00FFF5';
    monitorCtx.shadowBlur = isLightMode ? 0 : 8;
    monitorCtx.lineWidth = 3;
    monitorCtx.beginPath();
    
    const startX = monitorCanvas.width - (monitorPoints.length * 2.8);
    let isDrawing = false;
    for (let i = 0; i < monitorPoints.length; i++) {
        const x = startX + (i * 2.8);
        const y = monitorPoints[i];
        if (y > 0) {
            if (!isDrawing) {
                monitorCtx.moveTo(x, y);
                isDrawing = true;
            } else {
                monitorCtx.lineTo(x, y);
            }
        } else {
            isDrawing = false;
        }
    }
    monitorCtx.stroke();
    monitorCtx.shadowBlur = 0;

    if (monitorPoints.length > 0) {
        const lastY = monitorPoints[monitorPoints.length - 1];
        if (lastY > 0) {
            monitorCtx.fillStyle = '#ffffff';
            monitorCtx.beginPath();
            monitorCtx.arc(monitorCanvas.width - 2, lastY, 6, 0, Math.PI * 2);
            monitorCtx.fill();
        }
    }

    monitorAnimFrame = requestAnimationFrame(animateMonitor);
}

function fluctuateMonitorGauges() {
    if (activeSimTab !== 'free') return;

    const devValue = Math.floor(8 + Math.sin(monitorTime * 1.5) * 5 + (Math.random() - 0.5) * 3);
    const valDev = document.getElementById('valDev');
    if (valDev) {
        valDev.textContent = (devValue >= 0 ? "+" : "") + devValue;
        const barFill = document.getElementById('barFillDev');
        if (barFill) {
            const fillHeight = Math.abs(devValue) / 50 * 50;
            barFill.style.height = fillHeight + '%';
            barFill.style.bottom = devValue >= 0 ? '50%' : '';
            barFill.style.top = devValue < 0 ? '50%' : '';
        }
    }

    updateGaugeValue('ringLoud', 'valLoud', Math.floor(75 + Math.sin(monitorTime) * 4 + (Math.random() - 0.5) * 2));
    updateGaugeValue('ringBright', 'valBright', Math.floor(86 + Math.cos(monitorTime * 0.8) * 2 + (Math.random() - 0.5) * 1));
    updateGaugeValue('ringPure', 'valPure', Math.floor(92 + Math.sin(monitorTime * 2.2) * 1.5));
    updateGaugeValue('ringStab', 'valStab', Math.floor(94 + Math.cos(monitorTime * 3) * 1.5));
}

function updateGaugeValue(ringId, valId, value) {
    const ring = document.getElementById(ringId);
    const val = document.getElementById(valId);
    if (val) val.textContent = value;
    if (ring) {
        ring.style.background = `conic-gradient(var(--primary-purple) ${value}%, var(--gauge-ring-empty) ${value}%, var(--gauge-ring-empty) 100%)`;
    }
}



/* ==========================================================
   5. Simulation: Vocal Diagnosis (歌声检测 - 5-Axis Radar)
   ========================================================== */
let simDiagnosisTimer = null;
let diagnosisSeconds = 0;
let activeSimReportData = null;

// Dynamic Toast alert container helper
function showSimToast(title, message, type = 'info') {
    let container = document.getElementById('simToastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'simToastContainer';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `vocalmap-toast ${type}`;
    
    let iconHTML = '';
    if (type === 'success') {
        iconHTML = `<svg class="vocalmap-toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
    } else if (type === 'warning') {
        iconHTML = `<svg class="vocalmap-toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`;
    } else if (type === 'error') {
        iconHTML = `<svg class="vocalmap-toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
    } else {
        iconHTML = `<svg class="vocalmap-toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
    }

    toast.innerHTML = `
        ${iconHTML}
        <div class="vocalmap-toast-content">
            <div class="vocalmap-toast-title">${title}</div>
            <div class="vocalmap-toast-message">${message}</div>
        </div>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 50);
    
    const dismiss = () => {
        if (toast.classList.contains('dismissed')) return;
        toast.classList.add('dismissed');
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode === container) {
                container.removeChild(toast);
            }
        }, 400);
    };
    
    toast.addEventListener('click', dismiss);
    setTimeout(dismiss, 4000);
}

// Global Audio Context initialized on user gesture
let simAudioContext = null;
function initSimAudioContext() {
    if (!simAudioContext) {
        simAudioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (simAudioContext.state === 'suspended') {
        simAudioContext.resume();
    }
}
document.addEventListener('click', initSimAudioContext, { once: false });

// Audio feedback guide tone synthesizer (Additive synthesis mimicking a piano strike)
function playSimGuideTone(midiNote, durationSeconds = 0.8, volumeMultiplier = 1.0) {
    initSimAudioContext();
    if (!simAudioContext || simAudioContext.state === 'suspended') return;
    
    if (!window.simPianoCompressor) {
        window.simPianoCompressor = simAudioContext.createDynamicsCompressor();
        window.simPianoCompressor.threshold.value = -10;
        window.simPianoCompressor.knee.value = 10;
        window.simPianoCompressor.ratio.value = 10;
        window.simPianoCompressor.attack.value = 0.003;
        window.simPianoCompressor.release.value = 0.15;
        window.simPianoCompressor.connect(simAudioContext.destination);
    }
    
    const freq = 440 * Math.pow(2, (midiNote - 69) / 12);
    
    const masterGain = simAudioContext.createGain();
    masterGain.gain.setValueAtTime(0, simAudioContext.currentTime);
    masterGain.gain.linearRampToValueAtTime(0.6 * volumeMultiplier, simAudioContext.currentTime + 0.015);
    masterGain.gain.exponentialRampToValueAtTime(0.001, simAudioContext.currentTime + durationSeconds + 0.25);
    
    const filter = simAudioContext.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(Math.min(freq * 4, 3000), simAudioContext.currentTime);
    filter.frequency.exponentialRampToValueAtTime(Math.min(freq * 1.2, 850), simAudioContext.currentTime + durationSeconds);
    filter.Q.value = 1.0;
    
    masterGain.connect(filter);
    filter.connect(window.simPianoCompressor);
    
    const createOsc = (type, freqRatio, gainLevel) => {
        const osc = simAudioContext.createOscillator();
        const oscGain = simAudioContext.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq * freqRatio, simAudioContext.currentTime);
        oscGain.gain.value = gainLevel;
        osc.connect(oscGain);
        oscGain.connect(masterGain);
        osc.start(simAudioContext.currentTime);
        osc.stop(simAudioContext.currentTime + durationSeconds + 0.35);
    };
    
    createOsc('triangle', 1, 0.5);
    createOsc('sine', 0.5, 0.2);
    createOsc('sine', 2, 0.12);
    createOsc('sine', 3, 0.04);
}

// Compact robust autocorrelation algorithm for pitch estimation
function autoCorrelate(buffer, sampleRate) {
    let SIZE = buffer.length;
    let rms = 0;
    for (let i = 0; i < SIZE; i++) {
        let val = buffer[i];
        rms += val * val;
    }
    rms = Math.sqrt(rms / SIZE);
    if (rms < 0.008) return -1; // insufficient signal

    let r1 = 0, r2 = SIZE - 1, thres = 0.15;
    for (let i = 0; i < SIZE / 2; i++) {
        if (Math.abs(buffer[i]) < thres) { r1 = i; break; }
    }
    for (let i = SIZE - 1; i >= SIZE / 2; i--) {
        if (Math.abs(buffer[i]) < thres) { r2 = i; break; }
    }

    buffer = buffer.slice(r1, r2);
    SIZE = buffer.length;

    let c = new Float32Array(SIZE);
    for (let i = 0; i < SIZE; i++) {
        for (let j = 0; j < SIZE - i; j++) {
            c[i] = c[i] + buffer[j] * buffer[j + i];
        }
    }

    let d = 0;
    while (c[d] > c[d + 1]) d++;
    let maxval = -1, maxpos = -1;
    for (let i = d; i < SIZE; i++) {
        if (c[i] > maxval) {
            maxval = c[i];
            maxpos = i;
        }
    }
    let T0 = maxpos;
    if (T0 < 0) return -1;

    let x1 = c[T0 - 1], x2 = c[T0], x3 = c[T0 + 1];
    let a = (x1 + x3 - 2 * x2) / 2;
    let b = (x3 - x1) / 2;
    if (a) T0 = T0 - b / (2 * a);

    return sampleRate / T0;
}

// Real-time microphone capture for pitch tracking
let simMicStream = null;
let simMicSource = null;
let simMicProcessor = null;
let simMicPitchHz = -1;

async function startSimMicTracking() {
    try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            console.warn("Microphone API not supported on this browser.");
            return;
        }
        initSimAudioContext();
        simMicStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        simMicSource = simAudioContext.createMediaStreamSource(simMicStream);
        simMicProcessor = simAudioContext.createScriptProcessor(2048, 1, 1);
        
        simMicSource.connect(simMicProcessor);
        simMicProcessor.connect(simAudioContext.destination);
        
        simMicProcessor.onaudioprocess = (e) => {
            const inputBuffer = e.inputBuffer.getChannelData(0);
            const hz = autoCorrelate(inputBuffer, simAudioContext.sampleRate);
            if (hz > 60 && hz < 1000) {
                simMicPitchHz = hz;
            } else {
                simMicPitchHz = -1;
            }
        };
        showSimToast("声学网关已建立", "麦克风已成功接入，声学系统正在提取音高频轨，请发声！", "success");
    } catch(err) {
        console.warn("Mic input error:", err);
        showSimToast("麦克风启动失败", "无法获取麦克风使用权限。系统将自动切入自动演示模式或鼠标控制。", "warning");
    }
}

function stopSimMicTracking() {
    if (simMicProcessor) { simMicProcessor.disconnect(); simMicProcessor = null; }
    if (simMicSource) { simMicSource.disconnect(); simMicSource = null; }
    if (simMicStream) {
        simMicStream.getTracks().forEach(track => track.stop());
        simMicStream = null;
    }
    simMicPitchHz = -1;
}

function hzToMidi(hz) { return 69 + 12 * Math.log2(hz / 440); }

// Vocal Diagnosis buttons binding
const btnStartSimDiagnosis = document.getElementById('btnStartSimDiagnosis');
const btnImportSimDiagnosis = document.getElementById('btnImportSimDiagnosis');
const btnStopSimDiagnosis = document.getElementById('btnStopSimDiagnosis');
const btnResetSimReport = document.getElementById('btnResetSimReport');
const importSimAudioDetectFile = document.getElementById('importSimAudioDetectFile');

if (btnStartSimDiagnosis) {
    btnStartSimDiagnosis.onclick = startSingRecording;
}
if (btnImportSimDiagnosis && importSimAudioDetectFile) {
    btnImportSimDiagnosis.onclick = () => {
        importSimAudioDetectFile.click();
    };
    
    importSimAudioDetectFile.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        importSimAudioDetectFile.value = ''; // reset value
        
        document.getElementById('simSingIdle').style.display = 'none';
        document.getElementById('simSingAnalyzing').style.display = 'flex';
        const analyzingText = document.getElementById('simSingAnalyzingText');
        analyzingText.textContent = `🚀 正在解码并分析音轨 [${file.name}]...`;
        
        try {
            initSimAudioContext();
            const arrayBuffer = await file.arrayBuffer();
            const audioBuffer = await simAudioContext.decodeAudioData(arrayBuffer);
            const duration = audioBuffer.duration;
            
            let pct = 0;
            const progressInterval = setInterval(() => {
                pct += 4;
                if (pct > 100) pct = 100;
                analyzingText.innerHTML = `
                    🚀 正在进行离线声学特征多维提取...<br>
                    <span style="font-size: 12px; color: var(--text-muted); display:block; margin: 4px 0;">[文件: ${file.name} | 时长: ${duration.toFixed(1)}s]</span>
                    <div style="width: 220px; height: 6px; background: rgba(255,255,255,0.05); border-radius: 3px; margin: 10px auto; overflow: hidden; border: 1px solid var(--glass-border);">
                        <div style="width: ${pct}%; height: 100%; background: linear-gradient(90deg, var(--primary-purple), var(--primary-cyan));"></div>
                    </div>
                    <span style="font-family: monospace; color: var(--primary-cyan); font-size: 12px;">已完成: ${pct}%</span>
                `;
                if (pct >= 100) {
                    clearInterval(progressInterval);
                    setTimeout(() => {
                        showImportedAudioReport(file.name, duration, file.size);
                    }, 400);
                }
            }, 80);
            
        } catch(err) {
            console.error("Audio decode error:", err);
            showSimToast("文件提取失败", "该音频格式不支持，请使用 WAV / MP3 / FLAC 原生格式！", "error");
            document.getElementById('simSingIdle').style.display = 'flex';
            document.getElementById('simSingAnalyzing').style.display = 'none';
        }
    };
}
if (btnStopSimDiagnosis) {
    btnStopSimDiagnosis.onclick = () => {
        clearInterval(simDiagnosisTimer);
        stopSimMicTracking();
        
        document.getElementById('simSingRecording').style.display = 'none';
        document.getElementById('simSingAnalyzing').style.display = 'flex';
        document.getElementById('simSingAnalyzingText').textContent = "正在综合分析刚才的演唱数据，请稍候...";
        
        setTimeout(() => {
            showMockSingReport();
        }, 1500);
    };
}
if (btnResetSimReport) {
    btnResetSimReport.onclick = () => {
        document.getElementById('simSingIdle').style.display = 'flex';
        document.getElementById('simSingReport').style.display = 'none';
        document.getElementById('simSingRecording').style.display = 'none';
        document.getElementById('simSingAnalyzing').style.display = 'none';
    };
}

function startSingRecording() {
    document.getElementById('simSingIdle').style.display = 'none';
    document.getElementById('simSingRecording').style.display = 'flex';
    document.getElementById('simSingReport').style.display = 'none';
    document.getElementById('simSingAnalyzing').style.display = 'none';

    diagnosisSeconds = 0;
    document.getElementById('simSingTimer').textContent = "0.0s";
    
    startSimMicTracking();

    simDiagnosisTimer = setInterval(() => {
        diagnosisSeconds += 0.1;
        document.getElementById('simSingTimer').textContent = diagnosisSeconds.toFixed(1) + "s";
        
        // Profesionally beep guiding piano tones during mic diagnostic recording
        if (Math.round(diagnosisSeconds * 10) % 15 === 0 && diagnosisSeconds > 0) {
            const notes = [60, 62, 64, 65, 67];
            const randNote = notes[Math.floor(Math.random() * notes.length)];
            playSimGuideTone(randNote, 0.22, 0.3);
        }
        
        if (diagnosisSeconds >= 6.0) {
            btnStopSimDiagnosis.click();
        }
    }, 100);
}

function showMockSingReport() {
    document.getElementById('simSingAnalyzing').style.display = 'none';
    document.getElementById('simSingReport').style.display = 'block';
    setSimRadarPreset('pro');
}

function showImportedAudioReport(fileName, duration, fileSize) {
    document.getElementById('simSingAnalyzing').style.display = 'none';
    document.getElementById('simSingReport').style.display = 'block';
    
    // Choose presets and add random variations
    const basePreset = simRadarPresets.pro;
    const randomScores = basePreset.scores.map(s => Math.min(100, Math.max(35, s + Math.floor(Math.random() * 11) - 5)));
    
    activeSimReportData = {
        title: `评估报告：${fileName}`,
        scores: randomScores,
        labels: basePreset.labels,
        keys: basePreset.keys,
        feedback: `全维声学诊断成功！检测到时长为 ${duration.toFixed(1)} 秒的高品质声轨。演唱音高起伏连贯，音准精度为 ${randomScores[0]}%，稳定度为 ${randomScores[1]}%。高声区共鸣响应优异。建议：可在长音收尾时放松下颚，适当混入适量气声，降低磨损，并确保 cents 音偏控制在黄金区间。`,
        findings: [
            { label: "起音音准命中率", value: randomScores[0], desc: `音轨起音贴合迅速，音准离散偏差均值约 ${(12 + Math.random()*8).toFixed(1)} cents。` },
            { label: "声带阻尼颤音波形", value: randomScores[4], desc: `颤音率表现稳定在 ${(5.4 + Math.random()*1.1).toFixed(1)}Hz，波峰波谷对称性高。` },
            { label: "共振峰共鸣比 (H1/H2)", value: randomScores[3], desc: `共鸣箱体深度共振，声音磁性饱满，高频共鸣增益表现亮丽。` }
        ],
        insights: [
            { pair: "音准 - 稳定度", desc: `演唱中气息稳定性高，即使在大跨度咬字转换瞬间，音高抖动依旧控制在正常 cents 范围内。` },
            { pair: "纯净度 - 共鸣", desc: `喉道打开充分，泛音结构清晰。但在极高音区间有声带轻微挤压，HNR轻微偏低。` }
        ],
        duration_sec: duration,
        data_size_kb: Math.round(fileSize / 1024),
        fileName: fileName
    };
    
    renderSimReport(activeSimReportData);
}

function renderSimReport(report) {
    document.getElementById('simReportTitle').textContent = report.title;

    // Render scores
    const grid = document.getElementById('simReportScoresGrid');
    grid.innerHTML = '';
    report.scores.forEach((val, idx) => {
        const c = val >= 80 ? '#00E676' : (val >= 50 ? '#FFEA00' : '#FF5252');
        const badge = document.createElement('div');
        badge.className = 'sim-score-badge';
        badge.style.borderLeft = `3px solid ${c}`;
        badge.innerHTML = `
            <span class="s-lbl">${report.labels[idx]}</span>
            <span class="s-vl" style="color: ${c}; font-weight:bold; font-size:16px;">${val}%</span>
        `;
        grid.appendChild(badge);
    });

    // Detail elements
    const detailsContainer = document.getElementById('simReportDetailsBlocks');
    let html = '';

    html += `
        <div class="sim-report-desc-box" style="margin-bottom:12px; font-size:12px; line-height:1.5; color: var(--text-muted); background: rgba(255,255,255,0.01); border: 1px solid var(--glass-border); padding: 12px; border-radius: 8px;">
            <b style="color: var(--text-main); font-size:13px; display:block; margin-bottom:4px;">综合声学评语：</b>
            ${report.feedback}
        </div>
    `;

    html += `<div style="color: var(--primary-cyan); font-size: 13px; font-weight: bold; margin-bottom: 6px; margin-top: 10px;">诊断发现</div>`;
    report.findings.forEach(f => {
        const c = f.value >= 80 ? 'var(--primary-cyan)' : (f.value >= 50 ? '#FFEA00' : 'var(--primary-red)');
        html += `
            <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--glass-border); padding: 8px 12px; border-radius: 8px; border-left: 3px solid ${c}; margin-bottom: 6px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2px;">
                    <span style="font-size:12px; color: var(--text-main); font-weight:bold;">${f.label}</span>
                    <span style="font-family: monospace; color: ${c}; font-weight:bold; font-size:13px;">${f.value}%</span>
                </div>
                <div style="color: var(--text-muted); font-size: 11px;">${f.desc}</div>
            </div>
        `;
    });

    html += `<div style="color: var(--primary-cyan); font-size: 13px; font-weight: bold; margin-bottom: 6px; margin-top: 10px;">多维交叉洞察</div>`;
    report.insights.forEach(ins => {
        html += `
            <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--glass-border); padding: 8px 12px; border-radius: 8px; border-left: 3px solid var(--primary-cyan); margin-bottom: 6px;">
                <div style="color: var(--primary-cyan); font-size: 11px; font-weight: bold; margin-bottom: 2px;">${ins.pair}</div>
                <div style="color: var(--text-muted); font-size: 11.5px; line-height:1.4;">${ins.desc}</div>
            </div>
        `;
    });

    html += `
        <div style="margin-top: 12px; color: var(--text-muted); font-size: 10px; border-top: 1px solid var(--glass-border); padding-top: 8px; font-family: monospace;">
            测试时长: ${report.duration_sec.toFixed(1)}s  |  数据包大小: ${report.data_size_kb}KB  |  协议类型: Fast-API WebRTC
        </div>
    `;

    detailsContainer.innerHTML = html;

    // Canvas radar drawing
    const canvas = document.getElementById('simReportRadarCanvas');
    if (canvas) {
        drawSimRadarChart(canvas, report);
    }
}

const simRadarPresets = {
    pro: {
        title: "评估预设：颤音大师 (Professional Vocalist)",
        scores: [94, 89, 87, 91, 96],
        labels: ["音准", "稳定", "纯净", "共鸣", "颤音"],
        keys: ["accuracy", "stability", "purity", "resonance", "vibrato"],
        feedback: "音准与颤音表现极其优异！您的颤音频率稳定在 5.8Hz 的声乐黄金区间，且波谷波峰高度对称。喉位控制良好，共鸣箱体打开充分，声音稳定度高。建议：可在中高音区咬字时注意降低气流的瞬态冲击力，进一步提高声音的纯净度。",
        findings: [
            { label: "起音音准命中率", value: 94, desc: "起音响应毫秒级贴合，无滑音寻找音高倾向，音高偏差均值 <15 cents。" },
            { label: "声带阻尼颤音波形", value: 96, desc: "成功提取颤音波动，波动频率为 5.8Hz，颤音振幅波动极度饱满。" },
            { label: "共振峰共鸣分布 (H1/H2)", value: 91, desc: "胸腔共鸣低频过渡至咽腔高频时，共振峰峰值突出，声音饱满厚实。" }
        ],
        insights: [
            { pair: "音准 - 稳定度", desc: "极佳的音准稳定性。即使在长句末端气息较弱时，音高偏差依然控制在 +12 cents 左右，体现了强大的横膈膜气息支撑。" },
            { pair: "纯净度 - 共鸣", desc: "共鸣箱完全打开，声音泛音华丽。虽然高音区有微弱的挤卡声带（HNR轻微偏低），但总体纯净磁性，质感突出。" }
        ]
    },
    beginner: {
        title: "评估预设：声乐小白 (Acoustic Beginner)",
        scores: [58, 52, 68, 45, 30],
        labels: ["音准", "稳定", "纯净", "共鸣", "颤音"],
        keys: ["accuracy", "stability", "purity", "resonance", "vibrato"],
        feedback: "音高有较明显的偏低（Flat）倾向，呼吸支持较弱导致长音稳定度不足。共鸣箱体未完全打开，发声带部分挤压导致泛音弱。建议：多使用关卡训练营的第一、二关卡进行基础音阶练习，稳固气息支撑。",
        findings: [
            { label: "起音音准命中率", value: 58, desc: "起音音准较差，存在向上滑音过渡的恶习，音准整体存在偏低趋势。" },
            { label: "长音气息防抖能力", value: 52, desc: "呼吸较浅，长音末端声带失控抖动剧烈（Jitter 偏差严重超出限制）。" },
            { label: "喉道共鸣箱体挤压", value: 45, desc: "喉道未向下打开，声带过度闭合挤压，声音显得单薄、缺乏高低泛音支撑。" }
        ],
        insights: [
            { pair: "音准 - 共鸣", desc: "音准偏差大主要是由发声挤压、共鸣点错位引起的。建议在唱歌前先打开喉头，使用哼鸣练习找准共鸣焦点，音准自然会随之改善。" },
            { pair: "稳定度 - 颤音", desc: "尚未掌握控制声带颤动的方法。目前的长音发抖属于声带脱力，而非健康的颤音。建议先集中练习稳健的长直音，不要盲目模仿颤音。" }
        ]
    },
    resonance: {
        title: "评估预设：共鸣大咖 (Resonance Master)",
        scores: [88, 85, 72, 95, 70],
        labels: ["音准", "稳定", "纯净", "共鸣", "颤音"],
        keys: ["accuracy", "stability", "purity", "resonance", "vibrato"],
        feedback: "胸腔与头腔共鸣转换非常圆润，泛音极度华丽（H1-H2评估优异），声音厚度足。音域跨度宽广，底音深厚。建议：在快速咬字时注意微调发声的连贯性，控制短时音准偏离。",
        findings: [
            { label: "声部泛音共鸣比 (H1/H2)", value: 95, desc: "共鸣箱体深度共振，声音富有磁性和空间环绕质感，泛音增益十分亮眼。" },
            { label: "起音音准命中率", value: 88, desc: "起音音高较准，但在辅音咬字瞬间有微小的起伏音偏，字头不够清晰干净。" },
            { label: "声带压迫沙哑度 (HNR)", value: 72, desc: "在中高音区有比较明显的真假声带过度摩擦情况，声带有轻度压迫沙哑。" }
        ],
        insights: [
            { pair: "共鸣 - 纯净度", desc: "尽管共鸣极佳，但由于气流速度控制不当导致声带有轻微挤卡，建议在咬字时适当收敛发声的冲力，混入适量气声，降低磨损。" },
            { pair: "音准 - 稳定度", desc: "长程音准掌控良好，气息稳固。仅在乐句换气点或声区衔接处有短时 pitch 偏移，建议多进行琶音连贯度练习。" }
        ]
    }
};

function setSimRadarPreset(presetKey) {
    const buttons = document.querySelectorAll('.report-presets-row button');
    buttons.forEach(btn => btn.classList.remove('active'));
    
    const activeBtn = Array.from(buttons).find(btn => btn.getAttribute('onclick').includes(presetKey));
    if (activeBtn) activeBtn.classList.add('active');

    const preset = simRadarPresets[presetKey];
    
    activeSimReportData = {
        title: preset.title,
        scores: preset.scores,
        labels: preset.labels,
        keys: preset.keys,
        feedback: preset.feedback,
        findings: preset.findings,
        insights: preset.insights,
        duration_sec: 6.2,
        data_size_kb: 256,
        fileName: "Microphone_Record"
    };
    
    renderSimReport(activeSimReportData);
}

function drawSimRadarChart(canvas, preset) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const cx = w / 2, cy = h / 2;
    const R = 90; 
    const labelR = R + 25;

    const N = preset.labels.length;
    const values = preset.scores;

    ctx.clearRect(0, 0, w, h);

    // Background concentric rings
    for (let level = 1; level <= 5; level++) {
        const r = (R / 5) * level;
        ctx.beginPath();
        for (let i = 0; i < N; i++) {
            const angle = -Math.PI / 2 + (2 * Math.PI / N) * i;
            const x = cx + r * Math.cos(angle);
            const y = cy + r * Math.sin(angle);
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.strokeStyle = isLightMode ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.04)';
        ctx.lineWidth = 0.8;
        ctx.stroke();
    }

    // Axes
    for (let j = 0; j < N; j++) {
        const a = -Math.PI / 2 + (2 * Math.PI / N) * j;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + R * Math.cos(a), cy + R * Math.sin(a));
        ctx.strokeStyle = isLightMode ? 'rgba(0, 0, 0, 0.03)' : 'rgba(255, 255, 255, 0.03)';
        ctx.stroke();
    }

    // Value Polygon
    ctx.beginPath();
    for (let k = 0; k < N; k++) {
        const angle = -Math.PI / 2 + (2 * Math.PI / N) * k;
        const dist = (values[k] / 100) * R;
        const px = cx + dist * Math.cos(angle);
        const py = cy + dist * Math.sin(angle);
        if (k === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
    }
    ctx.closePath();

    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
    grad.addColorStop(0, 'rgba(192, 132, 252, 0.35)');
    grad.addColorStop(1, 'rgba(0, 229, 255, 0.1)');
    ctx.fillStyle = grad;
    ctx.shadowBlur = 15;
    ctx.shadowColor = 'rgba(192, 132, 252, 0.45)';
    ctx.fill();
    ctx.strokeStyle = '#c084fc';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Dots and Values
    for (let m = 0; m < N; m++) {
        const a1 = -Math.PI / 2 + (2 * Math.PI / N) * m;
        const d1 = (values[m] / 100) * R;
        const dx = cx + d1 * Math.cos(a1);
        const dy = cy + d1 * Math.sin(a1);

        ctx.beginPath();
        ctx.arc(dx, dy, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#00FFF5';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#00FFF5';
        ctx.fill();
        ctx.shadowBlur = 0;

        const valColor = values[m] >= 80 ? '#00E676' : (values[m] >= 50 ? '#FFEA00' : '#FF5252');
        ctx.fillStyle = valColor;
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.fillText(Math.round(values[m]), dx, dy - 6);
    }

    // Labels
    ctx.fillStyle = isLightMode ? '#334155' : '#a399b5';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (let n = 0; n < N; n++) {
        const a2 = -Math.PI / 2 + (2 * Math.PI / N) * n;
        const lx = cx + labelR * Math.cos(a2);
        const ly = cy + labelR * Math.sin(a2);
        ctx.fillText(preset.labels[n], lx, ly);
    }
}

// Render high-fidelity report PNG image on off-screen canvas
function exportSimReportToImage(report) {
    showSimToast("导出图像中", "正在为您生成高精度 Obsidian 质感声学诊断长图，请稍候...", "info");
    
    setTimeout(() => {
        const c = document.createElement('canvas');
        c.width = 600;
        c.height = 1450;
        const ctx = c.getContext('2d');
        
        // Background Gradient
        const bgGrad = ctx.createLinearGradient(0, 0, 0, c.height);
        bgGrad.addColorStop(0, '#0a0712');
        bgGrad.addColorStop(0.3, '#100c1e');
        bgGrad.addColorStop(1, '#050308');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, c.width, c.height);
        
        // Grid pattern overlay (sleek tech style)
        ctx.strokeStyle = 'rgba(255,255,255,0.015)';
        ctx.lineWidth = 1;
        for (let x = 0; x < c.width; x += 40) {
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, c.height); ctx.stroke();
        }
        for (let y = 0; y < c.height; y += 40) {
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(c.width, y); ctx.stroke();
        }
        
        // Header Glow
        ctx.fillStyle = 'rgba(192, 132, 252, 0.08)';
        ctx.beginPath(); ctx.arc(300, 100, 200, 0, Math.PI*2); ctx.fill();
        
        // Header Text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 24px "Inter", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText("VocalMap Pro 声学全息诊断报告", 300, 75);
        
        ctx.fillStyle = '#00FFF5';
        ctx.font = '13px "JetBrains Mono", monospace';
        ctx.fillText("VOCAL ACOUSTIC HOLOGRAM DIAGNOSIS ENGINE", 300, 105);
        
        ctx.strokeStyle = 'rgba(0, 229, 255, 0.2)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(50, 130); ctx.lineTo(550, 130); ctx.stroke();
        
        // 5-Axis Radar Chart
        const cx = 300, cy = 320, R = 110;
        const N = report.labels.length;
        const values = report.scores;
        
        // Concentric rings
        for (let level = 1; level <= 5; level++) {
            const r = (R / 5) * level;
            ctx.beginPath();
            for (let i = 0; i < N; i++) {
                const angle = -Math.PI / 2 + (2 * Math.PI / N) * i;
                const rx = cx + r * Math.cos(angle);
                const ry = cy + r * Math.sin(angle);
                if (i === 0) ctx.moveTo(rx, ry);
                else ctx.lineTo(rx, ry);
            }
            ctx.closePath();
            ctx.strokeStyle = 'rgba(255,255,255,0.04)';
            ctx.stroke();
        }
        // Axes
        for (let j = 0; j < N; j++) {
            const a = -Math.PI / 2 + (2 * Math.PI / N) * j;
            ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + R * Math.cos(a), cy + R * Math.sin(a));
            ctx.strokeStyle = 'rgba(255,255,255,0.03)';
            ctx.stroke();
        }
        // Data Area
        ctx.beginPath();
        for (let k = 0; k < N; k++) {
            const angle = -Math.PI / 2 + (2 * Math.PI / N) * k;
            const dist = (values[k] / 100) * R;
            const px = cx + dist * Math.cos(angle);
            const py = cy + dist * Math.sin(angle);
            if (k === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.closePath();
        const radarGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
        radarGrad.addColorStop(0, 'rgba(192, 132, 252, 0.4)');
        radarGrad.addColorStop(1, 'rgba(0, 229, 255, 0.1)');
        ctx.fillStyle = radarGrad;
        ctx.fill();
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 3;
        ctx.stroke();
        
        // Radar dots and labels
        for (let m = 0; m < N; m++) {
            const a1 = -Math.PI / 2 + (2 * Math.PI / N) * m;
            const d1 = (values[m] / 100) * R;
            const dx = cx + d1 * Math.cos(a1);
            const dy = cy + d1 * Math.sin(a1);
            
            ctx.beginPath(); ctx.arc(dx, dy, 5, 0, Math.PI*2);
            ctx.fillStyle = '#00FFF5';
            ctx.fill();
            
            ctx.fillStyle = values[m] >= 80 ? '#00E676' : (values[m] >= 50 ? '#FFEA00' : '#FF5252');
            ctx.font = 'bold 12px monospace';
            ctx.fillText(Math.round(values[m]), dx, dy - 10);
            
            const lx = cx + (R + 25) * Math.cos(a1);
            const ly = cy + (R + 25) * Math.sin(a1);
            ctx.fillStyle = '#a399b5';
            ctx.font = 'bold 13px sans-serif';
            ctx.fillText(report.labels[m], lx, ly);
        }
        
        // Score Badges
        let bx = 60;
        let by = 490;
        let bw = 90;
        let bh = 45;
        report.scores.forEach((val, idx) => {
            const cColor = val >= 80 ? '#00E676' : (val >= 50 ? '#FFEA00' : '#FF5252');
            ctx.fillStyle = 'rgba(255,255,255,0.02)';
            ctx.strokeStyle = 'rgba(255,255,255,0.05)';
            ctx.lineWidth = 1;
            
            ctx.beginPath();
            ctx.roundRect(bx, by, bw, bh, 6);
            ctx.fill();
            ctx.stroke();
            
            ctx.fillStyle = cColor;
            ctx.fillRect(bx, by + 4, 3, bh - 8);
            
            ctx.fillStyle = '#a399b5';
            ctx.font = '11px sans-serif';
            ctx.fillText(report.labels[idx], bx + bw/2, by + 18);
            
            ctx.fillStyle = cColor;
            ctx.font = 'bold 16px monospace';
            ctx.fillText(`${val}%`, bx + bw/2, by + 37);
            
            bx += 100;
        });
        
        ctx.strokeStyle = 'rgba(255,255,255,0.05)';
        ctx.beginPath(); ctx.moveTo(50, 565); ctx.lineTo(550, 565); ctx.stroke();
        
        // Feedback Card
        ctx.fillStyle = 'rgba(255,255,255,0.01)';
        ctx.strokeStyle = 'rgba(255,255,255,0.04)';
        ctx.beginPath();
        ctx.roundRect(50, 590, 500, 160, 12);
        ctx.fill(); ctx.stroke();
        
        ctx.fillStyle = '#c084fc';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText("综合声学评语", 75, 625);
        
        ctx.fillStyle = '#a399b5';
        ctx.font = '14px sans-serif';
        wrapText(ctx, report.feedback, 75, 655, 450, 24);
        
        // Findings section
        ctx.fillStyle = '#00FFF5';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText("诊断发现 Details", 50, 790);
        
        let fy = 815;
        report.findings.forEach(f => {
            const cColor = f.value >= 80 ? '#00FFF5' : (f.value >= 50 ? '#FFEA00' : '#FF5252');
            ctx.fillStyle = 'rgba(255,255,255,0.015)';
            ctx.strokeStyle = 'rgba(255,255,255,0.04)';
            ctx.beginPath();
            ctx.roundRect(50, fy, 500, 80, 8);
            ctx.fill(); ctx.stroke();
            
            ctx.fillStyle = cColor;
            ctx.fillRect(50, fy, 4, 80);
            
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText(f.label, 70, fy + 28);
            
            ctx.fillStyle = cColor;
            ctx.font = 'bold 15px monospace';
            ctx.textAlign = 'right';
            ctx.fillText(`${f.value}%`, 530, fy + 28);
            ctx.textAlign = 'left';
            
            ctx.fillStyle = '#a399b5';
            ctx.font = '12px sans-serif';
            ctx.fillText(f.desc, 70, fy + 56);
            
            fy += 95;
        });
        
        // Insights section
        ctx.fillStyle = '#00FFF5';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText("多维交叉洞察 Insights", 50, fy + 15);
        
        let iy = fy + 40;
        report.insights.forEach(ins => {
            ctx.fillStyle = 'rgba(255,255,255,0.015)';
            ctx.strokeStyle = 'rgba(255,255,255,0.04)';
            ctx.beginPath();
            ctx.roundRect(50, iy, 500, 80, 8);
            ctx.fill(); ctx.stroke();
            
            ctx.fillStyle = '#00E676';
            ctx.fillRect(50, iy, 4, 80);
            
            ctx.fillStyle = '#00FFF5';
            ctx.font = 'bold 13px sans-serif';
            ctx.fillText(ins.pair, 70, iy + 26);
            
            ctx.fillStyle = '#a399b5';
            ctx.font = '12px sans-serif';
            wrapText(ctx, ins.desc, 70, iy + 48, 450, 18);
            
            iy += 95;
        });
        
        // Footer info block
        ctx.strokeStyle = 'rgba(255,255,255,0.05)';
        ctx.beginPath(); ctx.moveTo(50, iy + 10); ctx.lineTo(550, iy + 10); ctx.stroke();
        
        ctx.fillStyle = '#a399b5';
        ctx.font = '11px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`录制时长: ${report.duration_sec.toFixed(1)}s  |  数据量: ${report.data_size_kb}KB  |  分析时间: ${new Date().toLocaleString()}`, 300, iy + 35);
        ctx.fillText("由 VocalMap 桌面级工作站声学诊断引擎生成", 300, iy + 52);
        
        // Trigger download
        const url = c.toDataURL('image/png');
        const a = document.createElement('a');
        a.href = url;
        a.download = `VocalMap_Pro_Report_${new Date().getTime()}.png`;
        a.click();
        
        showSimToast("导出成功", " Obsidian 质感诊断报告长图已成功保存到本地！", "success");
    }, 600);
}

// Text wrapping helper
function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    let words = text.split('');
    let line = '';
    let testLine = '';
    
    for (let n = 0; n < words.length; n++) {
        testLine = line + words[n];
        let metrics = ctx.measureText(testLine);
        let testWidth = metrics.width;
        if (testWidth > maxWidth && n > 0) {
            ctx.fillText(line, x, y);
            line = words[n];
            y += lineHeight;
        } else {
            line = testLine;
        }
    }
    ctx.fillText(line, x, y);
}

// Bind Diagnosis buttons
const btnSimExportImage = document.getElementById('btnSimExportImage');
if (btnSimExportImage) {
    btnSimExportImage.onclick = () => {
        if (!activeSimReportData) {
            showSimToast("无法导出", "缺少诊断数据，请先录制或导入音频进行检测！", "warning");
            return;
        }
        exportSimReportToImage(activeSimReportData);
    };
}

const btnSimExportVmap = document.getElementById('btnSimExportVmap');
if (btnSimExportVmap) {
    btnSimExportVmap.onclick = () => {
        if (!activeSimReportData) {
            showSimToast("无法存为回放项目", "缺少诊断数据，请先录制或导入音频进行检测！", "warning");
            return;
        }
        
        const duration = activeSimReportData.duration_sec;
        const totalPoints = Math.round(duration * 20); 
        let trajectory = [];
        
        let currentPitch = simTrainingBaseMidi || 60;
        
        for (let i = 0; i < totalPoints; i++) {
            const time = i * 0.05;
            const baseWander = Math.sin(time * 0.8) * 3 + Math.cos(time * 1.5) * 1.5;
            const vibratoAmp = (activeSimReportData.scores[4] / 100) * 0.8;
            const vibrato = Math.sin(time * 2 * Math.PI * 5.8) * vibratoAmp;
            const centsDev = (Math.random() - 0.5) * 6 + (activeSimReportData.scores[0] < 80 ? (Math.random()-0.5)*20 : 0);
            const midiNote = currentPitch + baseWander + vibrato + (centsDev / 100);
            const hz = 440 * Math.pow(2, (midiNote - 69) / 12);
            
            trajectory.push({
                time: time,
                hz: hz,
                midi: midiNote,
                cents: centsDev,
                loudness: 70 + Math.sin(time * 1.2) * 12 + (Math.random() - 0.5) * 4,
                brightness: 80 + Math.cos(time * 0.9) * 8 + (Math.random() - 0.5) * 3,
                purity: 85 + Math.sin(time * 2) * 5,
                stability: 90 + Math.cos(time * 3) * 4
            });
        }
        
        window.cachedPlaybackProject = {
            fileName: activeSimReportData.fileName || "Microphone_Record.wav",
            duration: duration,
            trajectory: trajectory,
            radarScores: activeSimReportData.scores
        };
        
        showSimToast("项目已存入回放舱", "诊断项目已导出并复制到内存缓存舱！可在‘实时监视’面板中点击‘导入’进行全轨音高轨迹回放。", "success");
    };
}



function generateDefaultSampleProject() {
    const duration = 12.0;
    const totalPoints = Math.round(duration * 20);
    let trajectory = [];
    
    let notesSequence = [55, 58, 60, 62, 65, 67, 70, 67, 65, 62, 58, 55];
    
    for (let i = 0; i < totalPoints; i++) {
        const time = i * 0.05;
        const noteIdx = Math.floor((time / duration) * notesSequence.length) % notesSequence.length;
        const targetMidi = notesSequence[noteIdx];
        
        const vibrato = Math.sin(time * 2 * Math.PI * 5.6) * 0.5;
        const centsDev = 6 + Math.sin(time * 3) * 8 + (Math.random() - 0.5) * 3;
        const finalMidi = targetMidi + vibrato + (centsDev / 100);
        const hz = 440 * Math.pow(2, (finalMidi - 69) / 12);
        
        trajectory.push({
            time: time,
            hz: hz,
            midi: finalMidi,
            cents: centsDev,
            loudness: 72 + Math.sin(time * 0.8) * 8 + (Math.random() - 0.5) * 2,
            brightness: 84 + Math.cos(time * 1.1) * 5 + (Math.random() - 0.5) * 2,
            purity: 91 + Math.sin(time * 1.5) * 2,
            stability: 95 + Math.cos(time * 2) * 2
        });
    }
    
    return {
        fileName: "九儿_高音音色测试分析.wav",
        duration: duration,
        trajectory: trajectory,
        radarScores: [91, 93, 88, 92, 95]
    };
}

let isMonitorPlayingBack = false;
let monitorPlaybackTime = 0;
let monitorPlaybackInterval = null;
let activePlaybackProject = null;

function initMonitorPlayback(project) {
    activePlaybackProject = project;
    isMonitorPlayingBack = false;
    monitorPlaybackTime = 0;
    
    const slider = document.getElementById('simPlaybackSlider');
    const timeDisplay = document.getElementById('simPlaybackTime');
    const playPauseBtn = document.getElementById('simPlayPauseBtn');
    
    slider.value = 0;
    slider.max = project.trajectory.length - 1;
    timeDisplay.textContent = `0.0s / ${project.duration.toFixed(1)}s`;
    playPauseBtn.innerHTML = `<svg class="lucide-icon" viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> 播放`;
    
    monitorPoints = [];
    
    slider.oninput = () => {
        const idx = parseInt(slider.value);
        monitorPlaybackTime = idx * 0.05;
        timeDisplay.textContent = `${monitorPlaybackTime.toFixed(1)}s / ${project.duration.toFixed(1)}s`;
        updateMonitorFrameToIdx(idx);
    };
    
    playPauseBtn.onclick = () => {
        if (isMonitorPlayingBack) {
            pauseMonitorPlayback();
        } else {
            startMonitorPlayback();
        }
    };
}

function startMonitorPlayback() {
    isMonitorPlayingBack = true;
    const playPauseBtn = document.getElementById('simPlayPauseBtn');
    playPauseBtn.innerHTML = `<svg class="lucide-icon" viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg> 暂停`;
    
    initSimAudioContext();
    
    const slider = document.getElementById('simPlaybackSlider');
    const timeDisplay = document.getElementById('simPlaybackTime');
    
    clearInterval(monitorPlaybackInterval);
    
    let lastPlayedMidiNote = -1;
    
    monitorPlaybackInterval = setInterval(() => {
        const currentIdx = Math.round(monitorPlaybackTime / 0.05);
        if (currentIdx >= activePlaybackProject.trajectory.length) {
            pauseMonitorPlayback();
            monitorPlaybackTime = 0;
            slider.value = 0;
            timeDisplay.textContent = `0.0s / ${activePlaybackProject.duration.toFixed(1)}s`;
            updateMonitorFrameToIdx(0);
            return;
        }
        
        slider.value = currentIdx;
        timeDisplay.textContent = `${monitorPlaybackTime.toFixed(1)}s / ${activePlaybackProject.duration.toFixed(1)}s`;
        
        const pt = activePlaybackProject.trajectory[currentIdx];
        updateMonitorFrameToIdx(currentIdx);
        
        const midiNote = Math.round(pt.midi);
        if (midiNote !== lastPlayedMidiNote && pt.hz > 0) {
            playSimGuideTone(midiNote, 0.25, 0.45);
            lastPlayedMidiNote = midiNote;
        }
        
        monitorPlaybackTime += 0.05;
    }, 50);
}

function pauseMonitorPlayback() {
    isMonitorPlayingBack = false;
    const playPauseBtn = document.getElementById('simPlayPauseBtn');
    playPauseBtn.innerHTML = `<svg class="lucide-icon" viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> 播放`;
    clearInterval(monitorPlaybackInterval);
}

function updateMonitorFrameToIdx(idx) {
    if (!activePlaybackProject) return;
    const pt = activePlaybackProject.trajectory[idx];
    if (!pt) return;
    
    monitorPoints = [];
    const maxHist = 250;
    const startIdx = Math.max(0, idx - maxHist + 1);
    
    for (let i = 0; i < maxHist; i++) {
        const tIdx = startIdx + i;
        if (tIdx <= idx && tIdx < activePlaybackProject.trajectory.length) {
            const trajectoryPt = activePlaybackProject.trajectory[tIdx];
            if (trajectoryPt.hz > 0) {
                const midi = hzToMidi(trajectoryPt.hz);
                const y = 160 - (midi - 61) * 15; // C#4 (61) is mapped to Y=160
                monitorPoints.push(y);
            } else {
                monitorPoints.push(-1);
            }
        } else {
            monitorPoints.push(-1);
        }
    }
    
    const noteNames = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
    const nearestMidi = Math.round(pt.midi);
    const noteStr = noteNames[(nearestMidi % 12 + 12) % 12] + (Math.floor(nearestMidi / 12) - 1);
    
    const valPitchEl = document.getElementById('valPitch');
    if (valPitchEl) {
        valPitchEl.innerText = noteStr;
        valPitchEl.style.color = '#00FFF5';
    }
    const descPitchEl = document.getElementById('descPitch');
    if (descPitchEl) {
        descPitchEl.innerText = `${pt.hz.toFixed(1)} Hz (回放中)`;
    }
    
    const valDevEl = document.getElementById('valDev');
    if (valDevEl) {
        valDevEl.innerText = (pt.cents >= 0 ? "+" : "") + pt.cents.toFixed(0);
        const barFill = document.getElementById('barFillDev');
        if (barFill) {
            const fillHeight = Math.abs(pt.cents) / 50 * 50;
            barFill.style.height = fillHeight + '%';
            barFill.style.bottom = pt.cents >= 0 ? '50%' : '';
            barFill.style.top = pt.cents < 0 ? '50%' : '';
        }
    }
    
    updateGaugeValue('ringLoud', 'valLoud', Math.round(pt.loudness));
    updateGaugeValue('ringBright', 'valBright', Math.round(pt.brightness));
    updateGaugeValue('ringPure', 'valPure', Math.round(pt.purity));
    updateGaugeValue('ringStab', 'valStab', Math.round(pt.stability));
    
    setGaugeDesc('Loud', pt.loudness > 85 ? "💥 强音/爆音" : (pt.loudness < 30 ? "🤫 轻声" : "🗣️ 正常音量"));
    setGaugeDesc('Bright', pt.brightness > 70 ? "🟡 头声主导" : (pt.brightness < 40 ? "🟠 胸声主导" : "🔵 混声"));
    setGaugeDesc('Pure', pt.purity > 70 ? "🛡️ 闭合紧密" : (pt.purity < 50 ? "💨 气声漏气" : "🎵 声音集中"));
    setGaugeDesc('Stab', pt.stability > 90 ? "➖ 平稳长直" : (pt.stability < 60 ? "⚠️ 震荡" : "🌊 颤音自然"));
    setGaugeDesc('Dev', pt.cents > 15 ? "🔺 偏高 (Sharp)" : (pt.cents < -15 ? "🔻 偏低 (Flat)" : "✅ 命中靶心"));
}

/* ==========================================================
   6. Simulation: Target Vocal Training (关卡训练营)
   ========================================================== */
let selectedSimRangeId = null;
let selectedSimLevelId = null;

let isTrainingRunning = false;
let trainingAnimId = null;
let trainTime = 0;
let trainScore = 0;
let trainTargets = [];
let trainUserY = 140;
let activeTrainingMaxScore = 1.0;

const RANGE_MIDDLES_SIM = {
    'soprano': 72, 
    'mezzo': 69,   
    'alto': 65,    
    'tenor': 60,   
    'baritone': 55,
    'bass': 52     
};
let simTrainingBaseMidi = 60; 

function initTrainingView() {
    selectedSimRangeId = null;
    selectedSimLevelId = null;
    isTrainingRunning = false;

    document.getElementById('simTrainRangeView').style.display = 'block';
    document.getElementById('simTrainLevelView').style.display = 'none';
    document.getElementById('simTrainSessionView').style.display = 'none';
    document.getElementById('simTrainingResultModal').style.display = 'none';
    
    const panel = document.getElementById('simCustomRangeConfigPanel');
    panel.style.opacity = '0.3';
    panel.style.pointerEvents = 'none';
    
    document.querySelectorAll('.range-card').forEach(card => card.classList.remove('active'));
    
    initSimCustomRangeDropdowns();
}

function selectSimRange(rangeId) {
    selectedSimRangeId = rangeId;
    
    document.querySelectorAll('.range-card').forEach(card => {
        if (card.getAttribute('onclick').includes(rangeId)) {
            card.classList.add('active');
        } else {
            card.classList.remove('active');
        }
    });

    if (rangeId === 'custom') {
        const panel = document.getElementById('simCustomRangeConfigPanel');
        panel.style.opacity = '1';
        panel.style.pointerEvents = 'auto';
        panel.style.borderColor = 'var(--primary-cyan)';
        panel.style.background = 'rgba(0, 229, 255, 0.05)';
        updateSimCustomRange();
    } else {
        const panel = document.getElementById('simCustomRangeConfigPanel');
        panel.style.opacity = '0.3';
        panel.style.pointerEvents = 'none';
        panel.style.borderColor = '';
        panel.style.background = '';
        
        simTrainingBaseMidi = RANGE_MIDDLES_SIM[rangeId] || 60;
        
        setTimeout(() => {
            document.getElementById('simTrainRangeView').style.display = 'none';
            document.getElementById('simTrainLevelView').style.display = 'block';
            
            const names = { soprano: '女高音', mezzo: '女中音', alto: '女低音', tenor: '男高音', baritone: '男中音', bass: '男低音' };
            document.getElementById('simSelectedRangeName').textContent = names[rangeId] || rangeId;
        }, 200);
    }
}

function initSimCustomRangeDropdowns() {
    const lowest = document.getElementById('simLowestSelect');
    const highest = document.getElementById('simHighestSelect');
    if (lowest.options.length > 0) return;

    let optionsHTML = '';
    const notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    for (let m = 36; m <= 96; m++) {
        let octave = Math.floor(m / 12) - 1;
        let noteName = notes[m % 12] + octave;
        optionsHTML += `<option value="${m}">${noteName} (${m})</option>`;
    }
    lowest.innerHTML = optionsHTML;
    highest.innerHTML = optionsHTML;
    
    lowest.value = 48; // C3
    highest.value = 72; // C5
}

function updateSimCustomRange() {
    const lowest = parseInt(document.getElementById('simLowestSelect').value);
    const highest = parseInt(document.getElementById('simHighestSelect').value);
    const notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const getNote = (m) => notes[m % 12] + (Math.floor(m / 12) - 1);
    
    document.getElementById('simRangeCardCustomText').innerText = `${getNote(lowest)}(${lowest}) - ${getNote(highest)}(${highest})`;
}

function confirmSimCustomRange() {
    const lowest = parseInt(document.getElementById('simLowestSelect').value);
    const highest = parseInt(document.getElementById('simHighestSelect').value);
    
    if (lowest >= highest) {
        alert("最高音必须高于最低音！");
        document.getElementById('simHighestSelect').value = lowest + 12;
        updateSimCustomRange();
        return;
    }
    
    selectedSimRangeId = 'custom';
    simTrainingBaseMidi = Math.floor((lowest + highest) / 2);
    
    document.getElementById('simTrainRangeView').style.display = 'none';
    document.getElementById('simTrainLevelView').style.display = 'block';
    document.getElementById('simSelectedRangeName').textContent = "自定义声域";
}

function backToSimRange() {
    document.getElementById('simTrainLevelView').style.display = 'none';
    document.getElementById('simTrainRangeView').style.display = 'block';
}

function selectSimLevel(levelId) {
    selectedSimLevelId = levelId;
    document.getElementById('simTrainLevelView').style.display = 'none';
    document.getElementById('simTrainSessionView').style.display = 'flex';
    document.getElementById('simTrainingResultModal').style.display = 'none';

    startSimTrainingGame();
}

function exitSimTraining() {
    stopTrainingLoop();
    stopSimMicTracking();
    document.getElementById('simTrainSessionView').style.display = 'none';
    document.getElementById('simTrainLevelView').style.display = 'block';
    document.getElementById('simTrainingResultModal').style.display = 'none';
}

function generateSimTrainingSequence(level, baseMidi) {
    let sequence = [];
    let currentTime = 2.0; 
    
    const addNote = (midi, duration, type = 'normal', instruction = '') => {
        sequence.push({
            startTime: currentTime,
            duration: duration,
            midi: midi,
            type: type,
            instruction: instruction,
            played: false
        });
        currentTime += duration;
    };
    
    const addRest = (duration) => {
        currentTime += duration;
    };
    
    if (level === 1) {
        addNote(baseMidi, 3.0, 'normal', '平稳长音，调整呼吸');
        addRest(1.0);
        
        let scale = [0, 2, 4, 5, 7];
        scale.forEach(o => addNote(baseMidi + o, 0.8, 'normal', '顺阶上行，唤醒声带'));
        for (let i = 3; i >= 0; i--) {
            addNote(baseMidi + scale[i], 0.8, 'normal', '顺阶下行');
        }
        addRest(1.0);
        addNote(baseMidi, 3.0, 'normal', '回到基准音高');
    } else if (level === 2) {
        addNote(baseMidi, 6.0, 'stability', '超长音高保持，考核气息长程稳定');
        addRest(1.5);
        addNote(baseMidi + 2, 6.0, 'stability', '稳定气息输出，保持核心支撑');
        addRest(1.5);
        addNote(baseMidi, 4.0, 'stability', '稳健收尾');
    } else if (level === 3) {
        let bluesOffsets = [0, 3, 5, 7, 10, 12];
        addNote(baseMidi, 1.5, 'riff', '定音热身');
        addRest(0.8);
        
        bluesOffsets.forEach(o => addNote(baseMidi + o, 0.35, 'riff', '丝滑布鲁斯转音，放松喉头'));
        for (let i = 4; i >= 0; i--) {
            addNote(baseMidi + bluesOffsets[i], 0.35, 'riff', '转音下行');
        }
        addNote(baseMidi, 2.0, 'riff', '稳定落音');
    } else if (level === 4) {
        addNote(baseMidi, 2.0, 'precision', '定音准备，音高聚焦');
        addRest(1.0);
        addNote(baseMidi + 7, 2.0, 'precision', '大跨度五度跳跃，起音精准降落');
        addRest(1.0);
        addNote(baseMidi, 2.0, 'precision', '回到基准音高');
        addRest(1.0);
        addNote(baseMidi + 12, 2.5, 'precision', '八度高空跨越，避免滑音寻找');
    } else if (level === 5) {
        addNote(baseMidi - 7, 3.0, 'chest', '低音区：声带闭合严实，胸腔共鸣');
        addRest(1.0);
        addNote(baseMidi + 4, 3.0, 'mix', '中音区：混入面罩，均衡发声');
        addRest(1.0);
        addNote(baseMidi + 12, 3.0, 'head', '高音区：放松下巴，释放头声');
    } else {
        addNote(baseMidi, 2.0, 'normal', '大考开始：基准热身');
        addNote(baseMidi + 3, 0.4, 'riff', '快速跑动');
        addNote(baseMidi + 5, 0.4, 'riff', '快速跑动');
        addNote(baseMidi + 7, 0.4, 'riff', '快速跑动');
        addNote(baseMidi + 12, 4.0, 'stability', '头腔共鸣长音');
        addRest(1.0);
        addNote(baseMidi - 5, 3.0, 'chest', '胸腔共鸣沉底');
    }
    
    return sequence;
}

// Canvas Mouse steer support
let simTrainingCanvasMouseY = 140;
const simTrainingCanvas = document.getElementById('simTrainingCanvas');
if (simTrainingCanvas) {
    simTrainingCanvas.addEventListener('mousemove', (e) => {
        const rect = simTrainingCanvas.getBoundingClientRect();
        simTrainingCanvasMouseY = e.clientY - rect.top;
    });
}

function startSimTrainingGame() {
    isTrainingRunning = true;
    trainTime = 0;
    trainScore = 0;
    
    const names = ['热身激活', '气息稳定', '转音练习', '音准精修', '三类共鸣', '综合挑战'];
    document.getElementById('simActiveLevelName').textContent = `正在训练: 关卡 ${selectedSimLevelId} - ${names[selectedSimLevelId - 1]}`;
    document.getElementById('simScoreText').textContent = "0 / 100";
    document.getElementById('simScoreProgressBar').style.width = '0%';

    const canvas = document.getElementById('simTrainingCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    trainTargets = generateSimTrainingSequence(selectedSimLevelId, simTrainingBaseMidi);
    
    activeTrainingMaxScore = 0.001;
    trainTargets.forEach(t => {
        activeTrainingMaxScore += t.duration;
    });
    
    // Auto initiate mic tracking if auto-demo is unchecked
    const isAutoDemo = document.getElementById('simAutoDemoToggle').checked;
    if (!isAutoDemo) {
        startSimMicTracking();
    }

    const scrollSpeed = 80; 
    const playerX = 120;
    
    const simGetYFromMidi = (midi) => {
        const viewRange = 20;
        const viewCenter = simTrainingBaseMidi + 3;
        const normalized = (midi - (viewCenter - viewRange / 2)) / viewRange;
        return canvas.height - normalized * canvas.height;
    };

    function gameLoop() {
        if (!isTrainingRunning || activeSimTab !== 'pro' || activeProSubTab !== 'train') {
            stopTrainingLoop();
            stopSimMicTracking();
            return;
        }

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const isLookAheadOn = document.getElementById('simLookAheadToggle').checked;
        const isLatencyOn = document.getElementById('simLatencyToggle').checked;
        const autoDemo = document.getElementById('simAutoDemoToggle').checked;

        trainTime += 0.045;
        
        // Pitch mapping
        let targetUserY = 140;
        if (autoDemo) {
            let activeTarget = null;
            trainTargets.forEach(t => {
                if (t.startTime <= trainTime && (t.startTime + t.duration) >= trainTime) {
                    activeTarget = t;
                }
            });
            if (activeTarget) {
                const vib = Math.sin(trainTime * 8.5) * 5;
                targetUserY = simGetYFromMidi(activeTarget.midi) + vib;
            } else {
                targetUserY = 140 + Math.sin(trainTime * 0.5) * 15;
            }
            trainUserY += (targetUserY - trainUserY) * 0.15;
        } else if (simMicPitchHz > 0) {
            const userMidi = hzToMidi(simMicPitchHz);
            targetUserY = simGetYFromMidi(userMidi);
            trainUserY += (targetUserY - trainUserY) * 0.35;
        } else {
            targetUserY = simTrainingCanvasMouseY;
            trainUserY += (targetUserY - trainUserY) * 0.25;
        }

        // Draw pitch grid lines
        ctx.strokeStyle = 'rgba(255,255,255,0.035)';
        ctx.lineWidth = 1;
        const viewRange = 20;
        const viewCenter = simTrainingBaseMidi + 3;
        let minMidi = Math.floor(viewCenter - viewRange / 2);
        let maxMidi = Math.ceil(viewCenter + viewRange / 2);
        for (let m = minMidi; m <= maxMidi; m++) {
            let y = simGetYFromMidi(m);
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
            
            if (m % 12 === 0) {
                ctx.fillStyle = 'rgba(0, 229, 255, 0.1)';
                ctx.fillRect(0, y - 1, canvas.width, 2);
                ctx.fillStyle = 'rgba(0, 229, 255, 0.35)';
                ctx.font = 'bold 9px monospace';
                const octave = Math.floor(m / 12) - 1;
                ctx.fillText(`C${octave}`, 10, y - 4);
            }
        }

        const lastTarget = trainTargets[trainTargets.length - 1];
        const endTime = lastTarget.startTime + lastTarget.duration;
        if (trainTime > endTime + 2.0) {
            stopTrainingLoop();
            stopSimMicTracking();
            showTrainingChallengeResult();
            return;
        }

        // Draw targets blocks
        let activeTarget = null;
        ctx.lineWidth = 1.5;
        
        trainTargets.forEach(t => {
            if (!t.played && trainTime >= t.startTime - 0.05) {
                t.played = true;
                if (trainTime < t.startTime + 0.5) {
                    playSimGuideTone(t.midi, t.duration);
                }
            }
            
            let startX = playerX + (t.startTime - trainTime) * scrollSpeed;
            let width = t.duration * scrollSpeed;
            let y = simGetYFromMidi(t.midi);
            
            if (startX <= playerX && (startX + width) >= playerX) {
                activeTarget = t;
            }
            
            if (t.hit) {
                ctx.fillStyle = 'rgba(0, 229, 255, 0.35)';
                ctx.strokeStyle = '#00E5FF';
                ctx.shadowColor = '#00E5FF';
                ctx.shadowBlur = 6;
            } else if (startX <= playerX && (startX + width) >= playerX) {
                ctx.fillStyle = 'rgba(255, 82, 82, 0.15)';
                ctx.strokeStyle = '#FF5252';
                ctx.shadowBlur = 0;
            } else {
                ctx.fillStyle = 'rgba(192, 132, 252, 0.12)';
                ctx.strokeStyle = 'rgba(192, 132, 252, 0.35)';
                ctx.shadowBlur = 0;
            }
            
            ctx.beginPath();
            ctx.roundRect(startX, y - 10, width, 20, 4);
            ctx.fill(); ctx.stroke();
            ctx.shadowBlur = 0;
            
            if (startX > 0 && startX < canvas.width) {
                ctx.fillStyle = t.hit ? '#00E5FF' : 'rgba(255,255,255,0.35)';
                ctx.font = "8px monospace";
                ctx.fillText(t.type, startX + 4, y - 14);
            }
        });

        // Hit checking
        let isHitFrame = false;
        let hitReasonText = "";
        
        if (activeTarget) {
            const userMidi = viewCenter - viewRange/2 + ((canvas.height - trainUserY) / canvas.height) * viewRange;
            const error = Math.abs(userMidi - activeTarget.midi);
            const maxAllowedError = (activeTarget.type === 'precision') ? 0.35 : 0.75;
            
            if (error <= maxAllowedError) {
                isHitFrame = true;
                activeTarget.hit = true;
                
                trainScore += (0.045 / activeTrainingMaxScore) * 100;
                if (trainScore > 100) trainScore = 100;
                
                document.getElementById('simScoreText').textContent = `${Math.floor(trainScore)} / 100`;
                document.getElementById('simScoreProgressBar').style.width = trainScore + '%';
                
                const labels = {
                    stability: "✓ 气息稳定!",
                    precision: "✓ 音准命中!",
                    chest: "✓ 胸腔共鸣!",
                    head: "✓ 头声充盈!",
                    normal: "✓ 命中目标!"
                };
                hitReasonText = labels[activeTarget.type] || "✓ 判定成功!";
            } else {
                hitReasonText = "❌ 音偏 (OUT)";
            }
        }

        if (hitReasonText) {
            ctx.fillStyle = isHitFrame ? '#00FFF5' : '#FF5252';
            ctx.font = 'bold 15px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(hitReasonText, canvas.width / 2, 45);
            ctx.textAlign = 'left';
        }

        // Draw judgment line
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.moveTo(playerX, 0); ctx.lineTo(playerX, canvas.height); ctx.stroke();
        ctx.setLineDash([]);

        // Mode overlay label
        let modeLabel = "自动演示模式 (AUTO)";
        if (!autoDemo) {
            modeLabel = simMicStream ? "麦克风物理模式 (MIC)" : "鼠标控制音高 (MOUSE - 上下移动鼠标)";
        }
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.font = '9px monospace';
        ctx.textAlign = 'right';
        ctx.fillText(modeLabel, canvas.width - 15, canvas.height - 15);
        ctx.textAlign = 'left';

        // Draw Player Cursor dot
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#ffffff';
        ctx.shadowBlur = 8;
        ctx.beginPath(); ctx.arc(playerX, trainUserY, 6, 0, Math.PI*2); ctx.fill();
        ctx.shadowBlur = 0;
        
        ctx.strokeStyle = '#00FFF5';
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(playerX, trainUserY, 12, 0, Math.PI*2); ctx.stroke();

        // Update mini gauges
        updateTrainingGauges(isLatencyOn);

        // Update instruction overlay
        let upcomingTarget = null;
        for (let i = 0; i < trainTargets.length; i++) {
            let t = trainTargets[i];
            let timeUntilStart = t.startTime - trainTime;
            let timeUntilEnd = (t.startTime + t.duration) - trainTime;
            if (timeUntilEnd > 0 && timeUntilStart < 2.5) {
                upcomingTarget = t;
                break;
            }
        }
        const overlayText = document.getElementById('simTrainingOverlayText');
        if (overlayText) {
            if (upcomingTarget && upcomingTarget.instruction) {
                overlayText.textContent = upcomingTarget.instruction;
            } else {
                overlayText.textContent = "保持呼吸稳定";
            }
        }

        trainingAnimId = requestAnimationFrame(gameLoop);
    }

    gameLoop();
}

function updateTrainingGauges(compensated) {
    const trainValPitch = document.getElementById('simTrainValPitch');
    const trainDescPitch = document.getElementById('simTrainDescPitch');
    
    const viewRange = 20;
    const viewCenter = simTrainingBaseMidi + 3;
    const userMidi = viewCenter - viewRange/2 + ((280 - trainUserY) / 280) * viewRange;
    const nearestMidi = Math.round(userMidi);
    
    const noteNames = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
    const noteStr = noteNames[(nearestMidi % 12 + 12) % 12] + (Math.floor(nearestMidi / 12) - 1);
    const hz = 440 * Math.pow(2, (userMidi - 69) / 12);
    
    if (trainValPitch && trainDescPitch) {
        trainValPitch.textContent = noteStr;
        trainDescPitch.textContent = `${hz.toFixed(1)} Hz`;
    }

    const dev = Math.floor((userMidi - nearestMidi) * 100);
    const trainValDev = document.getElementById('simTrainValDev');
    if (trainValDev) {
        trainValDev.textContent = (dev >= 0 ? "+" : "") + dev;
        const fill = document.getElementById('simTrainBarFillDev');
        if (fill) {
            fill.style.height = (Math.min(50, Math.abs(dev)) / 50 * 50) + '%';
            fill.style.bottom = dev >= 0 ? '50%' : '';
            fill.style.top = dev < 0 ? '50%' : '';
        }
    }

    const loudnessVal = Math.floor(74 + Math.sin(trainTime * 1.5) * 8 + (Math.random()-0.5)*4);
    const brightVal = Math.floor(82 + Math.cos(trainTime) * 6 + (Math.random()-0.5)*3);
    const purityVal = Math.floor(92 + Math.sin(trainTime * 2.2) * 3);
    const stabVal = Math.floor(compensated ? (94 + Math.sin(trainTime)*2) : (68 + Math.sin(trainTime * 5)*12));

    document.getElementById('simTrainValLoud').textContent = loudnessVal;
    document.getElementById('simTrainValBright').textContent = brightVal;
    document.getElementById('simTrainValPure').textContent = purityVal;
    document.getElementById('simTrainValStab').textContent = stabVal;
}

function stopTrainingLoop() {
    isTrainingRunning = false;
    if (trainingAnimId) {
        cancelAnimationFrame(trainingAnimId);
        trainingAnimId = null;
    }
}

function showTrainingChallengeResult() {
    const score = Math.floor(trainScore);
    document.getElementById('simTrainingResultScoreVal').textContent = score;

    let feedback = '';
    if (score >= 90) {
        feedback = `<b style="color: #00E676;">✓ 完美驾驭！</b><br>您的气息支撑与音准控制堪称专业级表现，共鸣腔体完全打开。您可以挑战更高的音域了！`;
    } else if (score >= 70) {
        feedback = `<b style="color: #00FFF5;">✓ 表现优秀！</b><br>您已成功掌握本关发声技巧。在音程切换边界上可以更加平滑连贯，继续保持练习！`;
    } else if (score >= 50) {
        feedback = `<b style="color: #FFEA00;">✓ 潜力很大！</b><br>音高命中方向基本正确，但在换声靶向点出现气息不稳，建议退回上一关巩固热身。`;
    } else {
        feedback = `<b style="color: #FF5252;">✗ 需要调整！</b><br>音准偏差较大，气息与音区有些不符。请在第一步确认选择适合自己的所属声域。`;
    }
    document.getElementById('simTrainingResultFeedback').innerHTML = feedback;

    const tutorials = [
        "【热身激活】目标是唤醒声带。得分的关键在于<b>放松喉头</b>，不要追求音量，而是追求在每个音符转换时的平滑度与音高的准确命中。",
        "【气息稳定】得分的关键是<b>控制呼气的均匀度</b>。在超长音期间，请使用横膈膜支撑，保持发光线条（稳定度 Stab）笔直，不要让声音发抖。",
        "【转音练习】得分的关键在于<b>颗粒感</b>。遇到密集的下行音阶，切忌滑音拖沓。可以在练习时加入微弱的“弹”的感觉，确保每个音都能单独被识别框捕获。",
        "【音准精修】面对大跨度跳跃，不要在滑动中寻找音高。得分秘诀是：在心里提前“听”到目标音，然后用气息<b>直接精准降落</b>在目标矩形内。",
        "【三类共鸣】得分要求不仅是音准！底音区需要您提高胸腔震动（声带闭合严实）；中音区需结合面罩共鸣；高音区需放松下巴，让气流冲击头腔（提升亮度 Brightness）。",
        "【综合挑战】这不仅考核声乐机能，更考核体力。高分的秘诀是学会<b>在间隙合理偷气</b>，在转音时收力，在长音时使用核心对抗。"
    ];
    document.getElementById('simTrainingResultTutorialText').innerHTML = tutorials[selectedSimLevelId - 1] || '';

    document.getElementById('simTrainingResultModal').style.display = 'flex';
}

function closeSimTrainingResultModal() {
    document.getElementById('simTrainingResultModal').style.display = 'none';
    exitSimTraining();
}

/* ==========================================================
   7. Simulation: Stem Separation (音轨分离)
   ========================================================== */
let isSimForceCPU = false;

function setSimDevice(device) {
    isSimForceCPU = (device === 'cpu');
    const btnGPU = document.getElementById('btnSimGPU');
    const btnCPU = document.getElementById('btnSimCPU');
    if (isSimForceCPU) {
        btnGPU.className = 'btn-ghost py-4 px-12 text-12';
        btnCPU.className = 'btn-cyan py-4 px-12 text-12';
    } else {
        btnGPU.className = 'btn-cyan py-4 px-12 text-12';
        btnCPU.className = 'btn-ghost py-4 px-12 text-12';
    }
}

function triggerMockUpload(type) {
    const inputName = type === 'inst' ? 'instUploadTitle' : 'vocUploadTitle';
    const startBtnId = type === 'inst' ? 'btnStartSepInst' : 'btnStartSepVoc';
    
    document.getElementById(inputName).innerHTML = `
        <span style="color:var(--primary-cyan); font-weight:bold;">🎤 mockup_vocal_audio.wav</span>
        <br><span style="color:var(--text-muted); font-size:11px;">12.4 MB</span>
    `;
    document.getElementById(startBtnId).style.display = 'block';
}

function startMockSeparation(type) {
    const startBtnId = type === 'inst' ? 'btnStartSepInst' : 'btnStartSepVoc';
    const loadingId = type === 'inst' ? 'simSepInstLoading' : 'simSepVocLoading';
    const progTextId = type === 'inst' ? 'simSepInstProgText' : 'simSepVocProgText';
    const resultsId = type === 'inst' ? 'simSepInstResults' : 'simSepVocResults';
    const zoneId = type === 'inst' ? 'simSepInstZone' : 'simSepVocZone';

    document.getElementById(startBtnId).style.display = 'none';
    document.getElementById(zoneId).style.display = 'none';
    document.getElementById(loadingId).style.display = 'block';

    let percent = 0;
    const messages = [
        "模型载入初始化中...",
        "音轨傅里叶频域交叉变换中 (Logic-RoFormer)...",
        "高动态频率特征分离提取中...",
        "生成无损音频波形文件..."
    ];

    const timer = setInterval(() => {
        percent += 8;
        if (percent > 100) percent = 100;
        const msg = messages[Math.floor((percent / 101) * messages.length)];
        document.getElementById(progTextId).textContent = `${msg} (${percent}%)`;

        if (percent === 100) {
            clearInterval(timer);
            document.getElementById(loadingId).style.display = 'none';
            document.getElementById(resultsId).style.display = 'block';

            if (type === 'inst') {
                renderInstStemsList();
            } else {
                initVocMixerWaveform();
            }
        }
    }, 150);
}

function resetMockSep(type) {
    const startBtnId = type === 'inst' ? 'btnStartSepInst' : 'btnStartSepVoc';
    const resultsId = type === 'inst' ? 'simSepInstResults' : 'simSepVocResults';
    const zoneId = type === 'inst' ? 'simSepInstZone' : 'simSepVocZone';
    const inputTitleId = type === 'inst' ? 'instUploadTitle' : 'vocUploadTitle';

    document.getElementById(resultsId).style.display = 'none';
    document.getElementById(startBtnId).style.display = 'none';
    document.getElementById(zoneId).style.display = 'block';
    document.getElementById(inputTitleId).textContent = "选择本地音频文件";
    
    if (type === 'voc') {
        stopVocMixerSynth();
    }
}

function renderInstStemsList() {
    const list = document.getElementById('simSepInstList');
    list.innerHTML = '';
    const stems = [
        { name: "人声 (Vocals)", color: "#00FFF5" },
        { name: "钢琴 (Piano)", color: "#FFEA00" },
        { name: "吉他 (Guitar)", color: "#00E676" },
        { name: "鼓组 (Drums)", color: "#FF5252" },
        { name: "贝斯 (Bass)", color: "#FF9100" }
    ];
    stems.forEach(stem => {
        const row = document.createElement('div');
        row.className = 'stem-result-row';
        row.style.borderLeftColor = stem.color;
        row.innerHTML = `
            <span>${stem.name}</span>
            <button class="btn-cyan py-2 px-8 text-11" onclick="alert('已模拟触发本地无损WAV下载进程！')">下载 WAV</button>
        `;
        list.appendChild(row);
    });
}

// Mixer player for Vocal/Acc separation using Web Audio API
let vocAudioCtx = null;
let vocGainLead = null;
let vocGainBacking = null;
let vocInterval = null;
let isVocPlaying = false;
let waveAnimFrameId = null;

function initVocMixerWaveform() {
    const visualizer = document.getElementById('sim-mix-wave');
    visualizer.innerHTML = '';
    for (let i = 0; i < 35; i++) {
        const bar = document.createElement('div');
        bar.className = (i % 2 === 0) ? 'wave-bar-inst' : 'wave-bar-vocal';
        bar.style.height = (20 + Math.random() * 60) + '%';
        visualizer.appendChild(bar);
    }

    const slider = document.getElementById('sim-blend-slider');
    slider.oninput = () => {
        const val = parseInt(slider.value);
        updateVocVolumeMix(val);
    };

    const playBtn = document.getElementById('sim-play-synth-btn');
    playBtn.onclick = () => {
        if (!isVocPlaying) {
            startVocMixerSynth();
        } else {
            stopVocMixerSynth();
        }
    };
}

function startVocMixerSynth() {
    if (!vocAudioCtx) {
        vocAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (vocAudioCtx.state === 'suspended') {
        vocAudioCtx.resume();
    }

    vocGainLead = vocAudioCtx.createGain();
    vocGainBacking = vocAudioCtx.createGain();
    
    const master = vocAudioCtx.createGain();
    master.gain.setValueAtTime(0.25, vocAudioCtx.currentTime);

    vocGainLead.connect(master);
    vocGainBacking.connect(master);
    master.connect(vocAudioCtx.destination);

    updateVocVolumeMix(parseInt(document.getElementById('sim-blend-slider').value));

    const notes = [293.66, 329.63, 349.23, 392.00, 392.00, 349.23, 329.63, 293.66];
    const chords = [146.83, 174.61, 196.00, 220.00];
    let step = 0;

    function tick() {
        const t = vocAudioCtx.currentTime;
        
        const backingOsc = vocAudioCtx.createOscillator();
        const backingGain = vocAudioCtx.createGain();
        backingOsc.type = 'triangle';
        backingOsc.frequency.setValueAtTime(chords[step % chords.length], t);
        backingGain.gain.setValueAtTime(0.15, t);
        backingGain.gain.exponentialRampToValueAtTime(0.001, t + 0.9);
        
        backingOsc.connect(backingGain);
        backingGain.connect(vocGainBacking);
        backingOsc.start(t);
        backingOsc.stop(t + 1.0);

        const leadOsc = vocAudioCtx.createOscillator();
        const leadGain = vocAudioCtx.createGain();
        leadOsc.type = 'sine';
        leadOsc.frequency.setValueAtTime(notes[step % notes.length], t);
        
        const lfo = vocAudioCtx.createOscillator();
        const lfoGain = vocAudioCtx.createGain();
        lfo.frequency.value = 5.8;
        lfoGain.gain.value = 3;
        lfo.connect(lfoGain);
        lfoGain.connect(leadOsc.frequency);
        lfo.start(t);
        lfo.stop(t + 0.45);

        leadGain.gain.setValueAtTime(0.22, t);
        leadGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

        leadOsc.connect(leadGain);
        leadGain.connect(vocGainLead);
        leadOsc.start(t);
        leadOsc.stop(t + 0.5);

        step++;
    }

    tick();
    vocInterval = setInterval(tick, 500);
    isVocPlaying = true;
    
    document.getElementById('sim-play-synth-btn').innerHTML = `
        <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><rect x="4" y="4" width="16" height="16" rx="2"></rect></svg>
        停止音频播放
    `;

    animateBlenderWavebars(true);
}

function stopVocMixerSynth() {
    if (vocInterval) {
        clearInterval(vocInterval);
        vocInterval = null;
    }
    if (vocAudioCtx) {
        vocAudioCtx.suspend();
    }
    isVocPlaying = false;
    
    const playBtn = document.getElementById('sim-play-synth-btn');
    if (playBtn) {
        playBtn.innerHTML = `
            <svg class="play-svg" viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
            播放双轨混音测试 (Web Audio Synth)
        `;
    }
    animateBlenderWavebars(false);
}

function updateVocVolumeMix(val) {
    if (!vocGainLead || !vocGainBacking) return;
    
    let leadVol = 1.0;
    let backingVol = 1.0;
    const label = document.getElementById('voc-mixer-tag');

    if (val < 0) {
        leadVol = (100 + val) / 100;
        backingVol = 1.0;
        if (label) label.textContent = `纯伴奏增强 (${val})`;
        document.querySelectorAll('.wave-bar-vocal').forEach(b => b.style.opacity = leadVol);
        document.querySelectorAll('.wave-bar-inst').forEach(b => b.style.opacity = 1);
    } else if (val > 0) {
        leadVol = 1.0;
        backingVol = (100 - val) / 100;
        if (label) label.textContent = `人声纯化提取 (+${val})`;
        document.querySelectorAll('.wave-bar-inst').forEach(b => b.style.opacity = backingVol);
        document.querySelectorAll('.wave-bar-vocal').forEach(b => b.style.opacity = 1);
    } else {
        if (label) label.textContent = `全部混音 (0)`;
        document.querySelectorAll('.wave-bar-inst').forEach(b => b.style.opacity = 1);
        document.querySelectorAll('.wave-bar-vocal').forEach(b => b.style.opacity = 1);
    }

    vocGainLead.gain.setTargetAtTime(leadVol, vocAudioCtx.currentTime, 0.05);
    vocGainBacking.gain.setTargetAtTime(backingVol, vocAudioCtx.currentTime, 0.05);
}

function animateBlenderWavebars(active) {
    if (!active) {
        cancelAnimationFrame(waveAnimFrameId);
        document.querySelectorAll('.wave-visualizer > div').forEach(bar => {
            bar.style.height = (20 + Math.random() * 65) + '%';
        });
        return;
    }

    const slider = document.getElementById('sim-blend-slider');
    const val = parseInt(slider.value);
    
    document.querySelectorAll('.wave-bar-inst').forEach(bar => {
        if (val < 90) {
            const scale = (100 - Math.max(0, val)) / 100;
            bar.style.height = (10 + Math.random() * 70 * scale) + '%';
        } else {
            bar.style.height = '4%';
        }
    });

    document.querySelectorAll('.wave-bar-vocal').forEach(bar => {
        if (val > -90) {
            const scale = (100 + Math.min(0, val)) / 100;
            bar.style.height = (10 + Math.random() * 70 * scale) + '%';
        } else {
            bar.style.height = '4%';
        }
    });

    waveAnimFrameId = requestAnimationFrame(() => animateBlenderWavebars(true));
}

/* ==========================================================
   8. Global Startup Initializers
   ========================================================== */
window.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initMouseGlowTracker();
    loadVersionInfo();
    initRealtimeMonitor();
    
    // Bind main header theme toggle button
    const pageThemeToggle = document.getElementById('theme-toggle');
    if (pageThemeToggle) {
        pageThemeToggle.addEventListener('click', toggleSimTheme);
    }
    
    // Switch to default monitor view
    switchSimTab('free');

    // Initialize Redesign Web Animations
    initWebAnimations();
});

// Expose result modal close globally
window.closeSimTrainingResultModal = closeSimTrainingResultModal;

/* ==========================================================
   9. Web Redesign Animations & Effects
   ========================================================== */

function initWebAnimations() {
    // 1. Loader Dismissal
    const loader = document.getElementById('page-loader');
    if (loader) {
        setTimeout(() => {
            loader.classList.add('fade-out');
            setTimeout(() => { loader.style.display = 'none'; }, 800);
        }, 1200); // 1.2s loader to show off the pulse
    }

    // 2. Sticky Header Scroll
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
        // Initial check
        if (window.scrollY > 50) navbar.classList.add('scrolled');
    }

    // 3. Scroll Reveal with Intersection Observer
    const revealElements = document.querySelectorAll('[data-reveal]');
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const delay = entry.target.getAttribute('data-reveal-delay') || 0;
                setTimeout(() => {
                    entry.target.classList.add('reveal-active');
                }, parseInt(delay));
                observer.unobserve(entry.target);
            }
        });
    }, {
        rootMargin: '0px 0px -100px 0px',
        threshold: 0.1
    });
    
    revealElements.forEach(el => revealObserver.observe(el));

    // 4. 3D Tilt Effect
    const tiltCards = document.querySelectorAll('.tilt-card, .tilt-card-large');
    tiltCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            // max rotation: 5deg for small, 2deg for large
            const maxRotate = card.classList.contains('tilt-card-large') ? 2 : 5;
            
            const rotateX = ((y - centerY) / centerY) * -maxRotate;
            const rotateY = ((x - centerX) / centerX) * maxRotate;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
        });
    });

    // 6. Apple-like Section Transition (Compromised Timing)
    const sections = document.querySelectorAll('section');
    window.addEventListener('scroll', () => {
        const windowHeight = window.innerHeight;
        
        sections.forEach((sec) => {
            const rect = sec.getBoundingClientRect();
            const container = sec.querySelector('.container') || sec.querySelector('.hero-container');
            if (!container) return;

            // Compromise: Start fading when the bottom of the section is just about to leave the bottom of the screen (90% mark).
            // This ensures tall sections are readable, but the transition starts reasonably early so it doesn't feel stuck.
            const fadeStartPoint = windowHeight * 0.9; 
            
            if (rect.bottom < fadeStartPoint && rect.bottom > -windowHeight) {
                // Calculate progress from 0 to 1 as it scrolls up
                let progress = (fadeStartPoint - rect.bottom) / (fadeStartPoint * 0.8); // 0.8 multiplier makes it fade out slightly faster
                progress = Math.min(Math.max(progress, 0), 1);
                
                // Non-linear easing (Ease-In cubic)
                const easeProgress = progress * progress * progress;
                
                // Parallax shift down and scale out
                const yOffset = easeProgress * 80; // max push down 80px
                const scale = 1 - (easeProgress * 0.06); // max scale down 0.94
                const opacity = 1 - (easeProgress * 1.5); // fade out curve
                
                container.style.transform = `translateY(${yOffset}px) scale(${scale})`;
                container.style.opacity = Math.max(0, opacity);
                container.style.transition = 'none'; // Follow scroll instantly
            } else if (rect.bottom >= fadeStartPoint) {
                // Fully visible
                container.style.transform = `translateY(0px) scale(1)`;
                container.style.opacity = 1;
                container.style.transition = 'transform 0.4s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.4s ease';
            }
        });
    });

    // 5. Hero Canvas Wave Visualizer
    initHeroWaveCanvas();
}

function initHeroWaveCanvas() {
    const canvas = document.getElementById('hero-wave-canvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    let width, height;
    
    function resizeCanvas() {
        width = canvas.parentElement.offsetWidth;
        height = canvas.parentElement.offsetHeight * 0.6;
        canvas.width = width;
        canvas.height = height;
    }
    
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    
    let time = 0;
    
    // Wave parameters
    const waves = [
        { yOffset: 0.6, amplitude: 30, frequency: 0.003, speed: 0.015, color: 'rgba(192, 132, 252, 0.4)' },
        { yOffset: 0.7, amplitude: 45, frequency: 0.002, speed: 0.02, color: 'rgba(0, 229, 255, 0.3)' },
        { yOffset: 0.8, amplitude: 20, frequency: 0.005, speed: 0.01, color: 'rgba(236, 72, 153, 0.2)' }
    ];
    
    let hoverAmplitudeMultiplier = 1;
    let targetMultiplier = 1;
    
    const heroSec = document.querySelector('.hero-section');
    if (heroSec) {
        heroSec.addEventListener('mouseenter', () => targetMultiplier = 2.5);
        heroSec.addEventListener('mouseleave', () => targetMultiplier = 1);
    }
    
    function draw() {
        ctx.clearRect(0, 0, width, height);
        time += 1;
        
        hoverAmplitudeMultiplier += (targetMultiplier - hoverAmplitudeMultiplier) * 0.05;
        
        waves.forEach((wave, index) => {
            ctx.beginPath();
            ctx.moveTo(0, height);
            
            for (let x = 0; x <= width; x += 5) {
                const noise = Math.sin(x * 0.01 + time * 0.05) * 5;
                const baseAmplitude = wave.amplitude * hoverAmplitudeMultiplier;
                
                const y = height * wave.yOffset 
                          + Math.sin(x * wave.frequency + time * wave.speed) * baseAmplitude 
                          + noise;
                
                ctx.lineTo(x, y);
            }
            
            ctx.lineTo(width, height);
            ctx.lineTo(0, height);
            ctx.closePath();
            
            const gradient = ctx.createLinearGradient(0, height * wave.yOffset - 50, 0, height);
            gradient.addColorStop(0, wave.color);
            gradient.addColorStop(1, 'rgba(0,0,0,0)');
            
            ctx.fillStyle = gradient;
            ctx.fill();
        });
        
        requestAnimationFrame(draw);
    }
    
    draw();
}
